American Legion 460 Website (AL460.org)

========

#### This repo will serve as the testbed for the AL460.org website as it is redesigned into a modern react site.

## You can see the final project [here](https://al460.org/)

